Stephanie Irish Paladin
200413341
CS215 - 001

website URL - http://www2.cs.uregina.ca/~srp796/Assignment1/index.html

css folder - contains css files
images folder - contains images
addnote.html - webpage that adds notes to the user's booking
index.html - homepage
book-room.html - lets user to book a room
room-booking-management.html - where user can add/edit/delete booking
signup.htnl - creates user account